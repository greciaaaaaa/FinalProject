//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Scholar on 7/29/24.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
