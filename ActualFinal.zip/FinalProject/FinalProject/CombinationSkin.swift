//
//  CombinationSkin.swift
//  FinalProject
//
//  Created by Scholar on 7/30/24.
//

import SwiftUI

struct CombinationSkin: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CombinationSkin()
}
